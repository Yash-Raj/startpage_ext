# Startpage

forked from kencx
Trying to make it firefox extension

Feel free to fork and make your own changes!

- Font: Fira Code
- Colorscheme: Gruvbox Dark
- Cat Gif: [Here](https://twitter.com/avogado6/status/1165595520967954432?s=19)

# ToDo
- ![startpage](startpage.gif)
- [Live Preview](https://kencx.github.io/startpage/)

